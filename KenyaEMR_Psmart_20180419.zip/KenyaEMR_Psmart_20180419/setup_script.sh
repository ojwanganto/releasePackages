#!/bin/bash
# Script to backup MySQL databases

modules_dir=/usr/share/tomcat6/.OpenMRS/modules
tomcat_dir=/var/lib/tomcat6/webapps/

#script directory
current_dir=$(pwd)
script_dir=$(dirname $0)

if [ $script_dir = '.' ]
then
script_dir="$current_dir"
fi
echo script_directory: ${script_dir}

# MySQL settings
mysql_user="root"
mysql_password="root"
mysql_base_database="openmrs"



# Read MySQL password from stdin if empty
if [ -z "${mysql_password}" ]; then
  echo -n "Enter MySQL ${mysql_user} password: "
  read -s mysql_password
  echo
fi

# Check MySQL password
echo exit | mysql --user=${mysql_user} --password=${mysql_password} -B 2>/dev/null
if [ "$?" -gt 0 ]; then
  echo "MySQL ${mysql_user} password incorrect"
  exit 1
else
  echo "MySQL ${mysql_user} password correct."
fi

sudo service tomcat6 stop

sudo cp ${current_dir}/webapp/*.war ${tomcat_dir}/


echo "Deleting old .omod files."
echo

sudo rm -R ${modules_dir}/*.omod


echo "Finished deleting old .omod files."
echo

echo "Copying new .omod files."
echo

sudo cp ${current_dir}/modules/*.omod ${modules_dir}/

echo "Finished copying new .omod files."
echo

echo "Granting read permission to the modules directory: ${modules_dir}."
sudo chmod --recursive +r ${modules_dir}/*.omod

sudo chown tomcat6:tomcat6  --recursive ${tomcat_dir}/
sudo chown tomcat6:tomcat6  --recursive ${modules_dir}/*.omod

echo "setting up KenyaEMR data tool"

echo "Creating new directory"
sudo rm -R "/opt/KenyaEMRDataTools/"
sudo mkdir "/opt/KenyaEMRDataTools/"
sudo chmod -R 755 /opt/KenyaEMRDataTools/
sudo chown -R $USER:$USER /opt/KenyaEMRDataTools/


cp --recursive ${current_dir}/kenyaEMRDataTool/lib/ /opt/KenyaEMRDataTools/
cp ${current_dir}/kenyaEMRDataTool/kenyaEMRQueryTools.jar /opt/KenyaEMRDataTools/
cp ${current_dir}/kenyaEMRDataTool/kenyaEMRDataToolsIcon.png /opt/KenyaEMRDataTools/
sudo rm ~/Desktop/KenyaEMRDataTools.desktop
cp ${current_dir}/kenyaEMRDataTool/KenyaEMRDataTools.desktop ~/Desktop

# make the desktop launcher executable
#sudo chown $USER:$USER ~/Desktop/KenyaEMRDataTools.desktop
sudo chmod +x ~/Desktop/KenyaEMRDataTools.desktop


echo "completed setup of data tool"
echo
echo "Starting tomcat..."
echo

sudo service tomcat6 start



