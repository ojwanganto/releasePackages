#!/bin/bash
# Script to backup MySQL databases

modules_dir=/usr/share/tomcat6/.OpenMRS/modules
tomcat_dir=/var/lib/tomcat6/webapps/

#script directory
current_dir=$(pwd)
script_dir=$(dirname $0)

if [ $script_dir = '.' ]
then
script_dir="$current_dir"
fi
echo script_directory: ${script_dir}

# MySQL settings
mysql_user="root"
mysql_password=""
mysql_base_database="openmrs"



# Read MySQL password from stdin if empty
if [ -z "${mysql_password}" ]; then
  echo -n "Enter MySQL ${mysql_user} password: "
  read -s mysql_password
  echo
fi

# Check MySQL password
echo exit | mysql --user=${mysql_user} --password=${mysql_password} -B 2>/dev/null
if [ "$?" -gt 0 ]; then
  echo "MySQL ${mysql_user} password incorrect"
  exit 1
else
  echo "MySQL ${mysql_user} password correct."
fi

sudo service tomcat6 stop

sudo cp ${current_dir}/webapp/*.war ${tomcat_dir}/

echo "upgrading Concept Dictionary to the latest"

mysql --user=${mysql_user} --password=${mysql_password} ${mysql_base_database} < "${script_dir}/dictionary/kenyaemr_v16_0_1_concepts_dump-2018-05-17.sql" 

if [ "$?" -gt 0 ]; then
  echo "MYSQL encountered a problem while processing KenyaEMR concepts."
  exit 1
else
  echo "Successfully updated concept dictionary .........................."
fi

echo "Deleting old .omod files."
echo

sudo rm -R ${modules_dir}/*.omod


echo "Finished deleting old .omod files."
echo

echo "Copying new .omod files."
echo

sudo cp ${current_dir}/modules/*.omod ${modules_dir}/

echo "Finished copying new .omod files."
echo

echo "Granting read permission to the modules directory: ${modules_dir}."
sudo chmod --recursive +r ${modules_dir}/*.omod

sudo chown tomcat6:tomcat6  --recursive ${tomcat_dir}/
sudo chown tomcat6:tomcat6  --recursive ${modules_dir}/*.omod
echo "Deleting liquibase entries for ETL module"
mysql --user=${mysql_user} --password=${mysql_password} ${mysql_base_database} -Bse "DELETE FROM liquibasechangelog where id like 'kenyaemrChart%' OR id like 'kenyaemr_hiv_testing%';"
echo
echo "Starting tomcat..."
echo

sudo service tomcat6 start



